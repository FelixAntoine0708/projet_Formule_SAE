#ifndef __GEN4_70CT_CLB__
#define __GEN4_70CT_CLB__

#include "gfx4desp32_gen4_ESP32_70CT.h"

#define gfx4desp32_gen4_ESP32_70CT_CLB gfx4desp32_gen4_ESP32_70CT

#endif // __GEN4_70CT_CLB__