// File generated 11/09/2023 11:52:41 am
// Warning! This is a generated file, any manual changes will be
// lost during the next generation.

#define  IFONT_OFFSET     0
// object indexes into ImageControl
#define iKnob1                  0 // offset 0x0
#define iLeddigits1             1 // offset 0x164600
#define iiLeddigits1            2 // offset 0x16A400


static const bool inputs[] PROGMEM = { true, false, false} ;
