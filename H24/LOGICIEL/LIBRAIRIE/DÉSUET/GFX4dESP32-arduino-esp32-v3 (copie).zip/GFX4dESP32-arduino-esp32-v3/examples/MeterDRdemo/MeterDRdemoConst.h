// File generated 18/09/2023 5:42:23 pm
// Warning! This is a generated file, any manual changes will be
// lost during the next generation.

#define  IFONT_OFFSET     0
// object indexes into ImageControl
#define iAngularmeter1          0 // offset 0x0
#define iLeddigits1             1 // offset 0xB18C00
#define iiLeddigits1            2 // offset 0xB1A600
#define iGauge1                 3 // offset 0xB1FA00
#define iWinbutton1             4 // offset 0xC4F800
#define iWinbutton2             5 // offset 0xC51800
#define iWinbutton3             6 // offset 0xC53800


static const bool inputs[] PROGMEM = { false, false, false, false, true, true, true} ;
