#ifndef __GEN4Q_43CT_CLB__
#define __GEN4Q_43CT_CLB__

#include "gfx4desp32_gen4_ESP32Q_43CT.h"

#define gfx4desp32_gen4_ESP32Q_43CT_CLB gfx4desp32_gen4_ESP32Q_43CT

#endif // __GEN4Q_43CT_CLB__