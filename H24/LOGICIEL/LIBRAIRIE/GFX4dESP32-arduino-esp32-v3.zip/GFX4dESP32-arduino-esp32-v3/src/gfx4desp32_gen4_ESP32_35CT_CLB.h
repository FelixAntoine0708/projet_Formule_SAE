#ifndef __GEN4_35CT_CLB__
#define __GEN4_35CT_CLB__

#include "gfx4desp32_gen4_ESP32_35CT.h"

#define gfx4desp32_gen4_ESP32_35CT_CLB gfx4desp32_gen4_ESP32_35CT

#endif // __GEN4_35CT_CLB__