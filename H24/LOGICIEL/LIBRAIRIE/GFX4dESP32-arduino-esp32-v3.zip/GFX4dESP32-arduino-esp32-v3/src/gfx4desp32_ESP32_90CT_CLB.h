#ifndef __GFX4D_90CT_CLB__
#define __GFX4D_90CT_CLB__

#include "gfx4desp32_ESP32_90CT.h"

#define gfx4desp32_ESP32_90CT_CLB gfx4desp32_ESP32_90CT

#endif // __GFX4D_90CT_CLB__