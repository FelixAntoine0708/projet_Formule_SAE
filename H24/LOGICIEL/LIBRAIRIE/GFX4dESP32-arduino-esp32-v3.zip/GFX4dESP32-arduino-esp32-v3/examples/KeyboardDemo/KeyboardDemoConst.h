// File generated 11/09/2023 9:32:47 am
// Warning! This is a generated file, any manual changes will be
// lost during the next generation.

 uint8_t iKeyboard1keystrokes[] {0x37, 0x38, 0x39, 0x34, 0x35, 0x36, 0x31, 0x32, 0x33, 0x2A, 0x30, 0x08
} ;


#define  IFONT_OFFSET     0
// object indexes into ImageControl
#define iKeyboard1              0 // offset 0x0
#define iKeyboard1_0            1 // offset 0x13400
#define iKeyboard1_1            2 // offset 0x16600
#define iKeyboard1_2            3 // offset 0x19800
#define iKeyboard1_3            4 // offset 0x1CA00
#define iKeyboard1_4            5 // offset 0x1FC00
#define iKeyboard1_5            6 // offset 0x22E00
#define iKeyboard1_6            7 // offset 0x26000
#define iKeyboard1_7            8 // offset 0x29200
#define iKeyboard1_8            9 // offset 0x2C400
#define iKeyboard1_9           10 // offset 0x2F600
#define iKeyboard1_10          11 // offset 0x32800
#define iKeyboard1_11          12 // offset 0x35A00

int8_t oKeyboard1[12] = {-1, 0, 0, 0, 0, 255, 255, 255, 255, 255, 12, 0} ;

static const bool inputs[] PROGMEM = { false, true, true, true, true, true, true, true, 
                  true, true, true, true, true} ;
