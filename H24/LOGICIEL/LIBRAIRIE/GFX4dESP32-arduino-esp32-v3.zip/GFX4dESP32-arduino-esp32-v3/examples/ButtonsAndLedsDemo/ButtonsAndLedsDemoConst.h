// File generated 11/09/2023 12:37:13 pm
// Warning! This is a generated file, any manual changes will be
// lost during the next generation.

#define  IFONT_OFFSET     0
// object indexes into ImageControl
#define iUserled1               0 // offset 0x0
#define iUserled2               1 // offset 0x8A00
#define iUserled3               2 // offset 0x11400
#define iUserled4               3 // offset 0x19E00
#define i4Dbutton1              4 // offset 0x22800
#define i4Dbutton2              5 // offset 0x26A00
#define i4Dbutton3              6 // offset 0x2AC00
#define i4Dbutton4              7 // offset 0x32E00


static const bool inputs[] PROGMEM = { false, false, false, false, true, true, true, true} ;
