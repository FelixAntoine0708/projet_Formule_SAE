// File generated 18/09/2023 9:26:08 am
// Warning! This is a generated file, any manual changes will be
// lost during the next generation.

#define  IFONT_OFFSET     0

static const bool inputs[] PROGMEM = {} ;
