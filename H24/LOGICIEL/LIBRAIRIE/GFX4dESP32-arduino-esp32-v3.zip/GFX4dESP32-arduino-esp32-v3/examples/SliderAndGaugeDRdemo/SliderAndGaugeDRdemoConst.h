// File generated 12/09/2023 7:43:27 am
// Warning! This is a generated file, any manual changes will be
// lost during the next generation.

#define  IFONT_OFFSET     0
// object indexes into ImageControl
#define iCoolgauge1             0 // offset 0x0
#define iSlider1                1 // offset 0x87EE00


static const bool inputs[] PROGMEM = { false, true} ;
